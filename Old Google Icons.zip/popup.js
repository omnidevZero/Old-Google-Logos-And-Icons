var donateButton = document.querySelector('#donate');

donateButton.onclick = function() {
  window.open("https://paypal.me/kowpowkow");
};